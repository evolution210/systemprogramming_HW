//_2017118012_YeJinHwa
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>

int main(int argc, char *argv[]){
	struct stat info;
	DIR *dir_ptr;
	struct dirent* direntp;
	char answer;
	char target[255];

	if(argc != 3)//command source target
		printf("Usage : %s source target\n",argv[0]);
	else{
		stat(argv[2],&info) == -1;
		
		if(S_ISDIR((&info)->st_mode)){//target == directory
			sprintf(target,"%s//%s",argv[2],argv[1]);//path settings
			rename(argv[1],target);//move file to directory 
		}

		else{//target == file
			if(strcmp(argv[1],argv[2])==0)//source name == target name
				printf("Those arguments are the same name\n");

			else{//source name != target name
				if((dir_ptr = opendir(".")) == NULL)//open current directory
					fprintf(stderr,"cannot open directory\n");
				else {
					while( (direntp = readdir(dir_ptr)) !=NULL){//check existence status
						if(strcmp(direntp->d_name,argv[2])==0){//if the target name is the name that exists 
							printf("error : File exists\ndoing anyway? (Y/N): ");
							scanf("%c",&answer);
							if(answer=='Y'){
								rename(argv[1],argv[2]);
								return 0;
							}
							else
								return 0;
						}
					}
					if(rename(argv[1],argv[2])!=0)//target name != exist name
						perror("Can`t rename file");
				}
			}
		}
	}
	return 0;
}
