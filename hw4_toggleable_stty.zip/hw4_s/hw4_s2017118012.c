//_2019_10_2_Yejinhwa
#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>
#include <string.h>

struct flaginfo{
	int fl_value;
	char *fl_char;
	char *fl_name;
};

struct flaginfo input_flags[] = {
        IGNBRK , "ignbrk" ,"Ignore break condition",
        BRKINT , "brkint" ,"Signal interrupt on break",
        IGNPAR , "ignpar" ,"Ignore chars with parity errors",
        PARMRK , "parmrk" ,"Mark parity errors",
        INPCK , "inpck" ,"Enable input parity check",
        ISTRIP , "istrip" ,"Strip character",

        INLCR , "inlcr" ,"Map NL to CR on input",
        IGNCR , "igncr" ,"Ignore CR",
        ICRNL , "icrnl" ,"Map CR to NL on input",
        IXON , "ixon" ,"Enable start/stop output control",

        IXOFF , "ixoff" ,"Enable start/stop input control",
       0,NULL,NULL
};

struct flaginfo local_flags[] = {
        ISIG , "isig" ,"Enable signals",
        ICANON , "icanon" ,"Canonical input (erase and kill)",

        ECHO , "echo" ,"Enable echo",
        ECHOE , "echoe" ,"Erase ERASE as BS-SPACE-BS",
        ECHOK , "echok" ,"Erase KILL by starting new line",
        0,NULL,NULL
};

struct flaginfo output_flags[] = {
	OLCUC , "olcuc" ,"Lowercase letter to uppercase"
};

void showbaud(int thespeed);
void show_some_flags(struct termios *ttyp);
void show_flagset(int thevalue, struct flaginfo thebitnames[]);

void Eopt(struct termios *ttyp,int *thevalue, struct flaginfo thebitnamesp[]);//-E option
void Sopt(struct termios *ttyp);//-S option

int main(int argc, char *argv[]){
	struct termios ttyinfo;
	if(tcgetattr(0,&ttyinfo) == -1){
		perror("Cannot get params about stdion");
		exit(1);
	}
	
	if(argc == 2){//exist option
		if(!(strcmp(argv[1],"-E"))){//-E option 
			Eopt(&ttyinfo,&((&ttyinfo)->c_iflag),input_flags);
			Eopt(&ttyinfo,&((&ttyinfo)->c_oflag),output_flags);
			Eopt(&ttyinfo,&((&ttyinfo)->c_lflag),local_flags);
		}
		else if(!(strcmp(argv[1],"-S"))){//-S option
			Sopt(&ttyinfo);	       		
		}
	}

	showbaud(cfgetospeed(&ttyinfo));
	printf("ERASE = ^%c; ",ttyinfo.c_cc[VERASE]-1+'A');
	printf("KILL = ^%c;\n",ttyinfo.c_cc[VKILL]-1+'A');
	show_some_flags(&ttyinfo);

	
}

void Eopt(struct termios *ttyp, int *thevalue, struct flaginfo thebitnames[]){//-E option
	int i;
	for(i=0;thebitnames[i].fl_value;i++){
		if(*thevalue & thebitnames[i].fl_value)//On
			*thevalue &= ~(thebitnames[i].fl_value); //on -> off
		else//off
			*thevalue |= thebitnames[i].fl_value; //off -> on
	}
	if(tcsetattr(0,TCSANOW,ttyp) == -1)//attribute setting
		printf("tcsetattr error\n");
}

void Sopt(struct termios *ttyp){//-S option
	int *flag_val[3] = {&(ttyp->c_iflag),&(ttyp->c_oflag),&(ttyp->c_lflag)};//termios member value array
	int flag_chr[3] = {IGNBRK,OLCUC,ECHOK};//flage_value array
	int i=0;

	for(i;i<3;i++){
		if(*flag_val[i] & flag_chr[i])//on
			*flag_val[i] &= ~(flag_chr[i]);//toggle
		else//off
			*flag_val[i] |= flag_chr[i];//toggle
	}
	if(tcsetattr(0,TCSANOW,ttyp) == -1)//attribute setting
		printf("tcsetattr error\n");
}

void showbaud(int thespeed){
	printf("SPEED ");
	switch(thespeed){
		case B300: printf("300"); break;
		case B600: printf("600"); break;
		case B1200: printf("1200"); break;
		case B1800: printf("1800"); break;
                case B2400: printf("2400"); break;
                case B4800: printf("4800"); break;
		case B9600: printf("9600"); break;
		default : printf("Fast"); break;

	}
	printf(" BAUD;\n");
}

void show_some_flags(struct termios *ttyp){
	show_flagset(ttyp->c_iflag, input_flags);
	show_flagset(ttyp->c_oflag, output_flags);
	show_flagset(ttyp->c_lflag, local_flags);
}

void show_flagset(int thevalue, struct flaginfo thebitnames []){
	int i;
	for(i=0; thebitnames[i].fl_value;i++){
	       if(thevalue & thebitnames[i].fl_value){
			printf("%s ",thebitnames[i].fl_char);       		
	       }
		else{
	 		printf("-%s ",thebitnames[i].fl_char);
		}
	}
	printf("\n\n");
}	

