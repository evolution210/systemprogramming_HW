#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
//#include <sys/wait.h>

FILE *popen2(const char*, const char*);

#define BUFF_SIZE 100
#define oops(m,x) {perror(m); exit(x);}

int main(){
	signal(SIGINT,SIG_IGN);
	signal(SIGQUIT,SIG_IGN);
	FILE *pipein_fp, *pipeout_fp;
	char readbuf[BUFF_SIZE];

	if( (pipein_fp = popen2("ls","r")) == NULL){
		perror("popen2");
		exit(1);
	}

	if( (pipeout_fp = popen2("sort -r","w")) == NULL){
		perror("popen2");
		exit(1);
	}

	while(fgets(readbuf,BUFF_SIZE,pipein_fp))
		fputs(readbuf,pipeout_fp);

	pclose(pipein_fp);
	pclose(pipeout_fp);
	sleep(1);

	return 0;
}

FILE *popen2(const char *command, const char *mode){
	int thepipe[2];
	FILE *fp;
	int pid;
	int p;

	if(*mode == 'r')
		p = 0;
	if(*mode == 'w')
		p = 1;

	if(pipe(thepipe) == -1){
		oops("pipe failed",1);
	}
	if( (pid = fork()) == -1){
		oops("cannot fork",2);
	}

	if(pid > 0){//parent
		close(thepipe[!p]);
		if(p == 0)//mode r
			fp = fdopen(thepipe[p],"r");
		else
			fp = fdopen(thepipe[p],"w");
		return fp;
	}

	else{//child
		close(thepipe[p]);
		if(p == 0)//mode r
			dup2(thepipe[!p],1);
		else
			dup2(thepipe[!p],0);
		execl("/bin/sh","sh","-c",command,NULL);
		exit(1);
	}

}
