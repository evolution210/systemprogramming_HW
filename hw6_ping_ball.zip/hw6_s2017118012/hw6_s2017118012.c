#include <stdio.h>
#include <string.h>
#include <curses.h>
#include <unistd.h>
#include <sys/time.h>
#include <signal.h>

#define BLANK " "

char ball;//symbol
int row;//ball_start_row
int col;//ball_start_col

int x_dir;//x coordinate direction
int y_dir;//y coordinate direction

int top;//tow_row
int bot;//bot_row
int left;//l_edge
int right;//r_edge

char input;//user`s input

int set_ticker(int n_msecs){
	struct itimerval new_timeset;
	long n_sec, n_usecs;

	n_sec = n_msecs / 1000;
	n_usecs = (n_msecs & 1000) * 1000L;

	new_timeset.it_interval.tv_sec = n_sec;
	new_timeset.it_interval.tv_usec = n_usecs;
	new_timeset.it_value.tv_sec = n_sec;
	new_timeset.it_value.tv_usec = n_usecs;

	return setitimer(ITIMER_REAL, &new_timeset, NULL);
}

void move_msg(int signum){
	signal(SIGALRM,move_msg);
	move(row,col);
	addstr(BLANK);

	switch(input){
		case 'r' : {x_dir*=2; if(x_dir >= 6) x_dir =4;}//maximum condition_x coordinate fast
			   break;
		case 'v' : {y_dir*=2; if(y_dir >= 6) y_dir =4;}//maximum condition_y coordinate fast
			   break;
		case 'e' : {x_dir/=2; if(x_dir < 1) x_dir = 1;}//x slow_minimum speed condition
			   break;
		case 'c' : {y_dir/=2; if(y_dir < 1) y_dir = 1;}//y_slow_minimun speen condition
			   break;
	}

	col += x_dir;
	row += y_dir;
	move(row, col);
	addch(ball);
	refresh();

	if(col <= left || col >= right-1)//bouncing
		x_dir = -(x_dir);
	if(row <= top || row >= bot-1)//bouncing
		y_dir = -(y_dir);
	input = '\0';//user`s input reset
}

int main(int argc, char *argv[]){
	int delay;
	int ndelay;
	int c;
	void move_msg(int);
	
	struct sigaction handler;//signal handling
	handler.sa_handler = SIG_IGN;//ignore SIGINT
	handler.sa_flags = SA_RESETHAND | SA_RESTART;

	if(sigaction(SIGINT,&handler,NULL) == -1)//sigaction
		perror("sigaction");

	initscr();
	crmode();
	noecho();
	clear();
	
	ball = *argv[1];//symbol
	row = atoi(argv[2]);//ball_start_row
	col = atoi(argv[3]);//ball_start_col
	top = atoi(argv[4]);//top_row
	bot = atoi(argv[5]);//bot_row
	left = atoi(argv[6]);//l_edge
	right = atoi(argv[7]);//r_edge
	
	x_dir = 1;
	y_dir = 1;
	delay = 1000;

	move(row,col);
	addch(ball);
	signal(SIGALRM,move_msg);
	set_ticker(delay);

	while(true){
		ndelay = 0;
		c = getch();
		if(c == 'Q') break;//Quit
		if(c == 'r' && delay >2) {ndelay = delay/2; input = 'r';}//x coordinate speed up
		if(c == 'v' && delay >2) {ndelay = delay/2; input = 'v';}//y coordinate speed up
		if(c == 'e') {ndelay = delay*2; input = 'e';}//x coordinate slow down
		if(c == 'c') {ndelay = delay*2; input = 'c';}//y coordinate slow down
		if(ndelay >0)
			set_ticker(delay = ndelay);
	}
	endwin();
	return 0;
}
