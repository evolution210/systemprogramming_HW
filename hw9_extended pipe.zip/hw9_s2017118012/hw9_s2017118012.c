#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

#define PIPE_ENDS 2
#define oops(m,x) { perror(m); exit(x); }

int main(int argc, char* argv[]){
	int thepipe[PIPE_ENDS], newfd, pid;//origin code
	int pipe2[PIPE_ENDS], pid2;//add code
	if(argc < 2){
		fprintf(stderr, "usage: pipe cmd1 cmd2\n");
		exit(1);
	}
	if(argc == 2){//one input
		execlp(argv[1],argv[1],NULL);
		return 0;
	}

	if(pipe (thepipe) == -1){//make pipe parent-child1
		oops("Cannot get a pipe", 1);
	}
	if((pid = fork()) == -1)//create child1
		oops("Cannot fork",2);

	if(pid > 0){//parent
		if(argc == 3){//two inputs
			close(thepipe[1]);//close write pipe_fd4
			if(dup2(thepipe[0],0) == -1)//dup fd4-stdin
				oops("couldn`t redirect stdin",3);
			close(thepipe[0]);//close origin read pipe_fd3
			execlp(argv[2],argv[2],NULL);
			oops(argv[2],3);
		}

		else{//three, four inputs
			if(pipe(pipe2) == -1){//make pipe parent-child2
				oops("Cannot get a pipe",1);
			}
			if((pid2 = fork()) == -1)//create child2
				oops("Cannot fork2",2);
		
			if(pid2 == 0){//child2_broker
				close(thepipe[1]);//close write pipe_fd4
				close(pipe2[0]);//close read pipe_fd5

				if(dup2(thepipe[0],0) == -1)//dup fd3_stdin
                                        oops("couldn`t redirect ch1 stdin",3);
                                close(thepipe[0]);//close origine read pipe_fd3

				if(dup2(pipe2[1],1) == -1)//dup fd6_stdout
					oops("couldn`t redirect ch2 stdout",3);
				close(pipe2[1]);//close origine write pipe_fd6	
				execlp(argv[2],argv[2],NULL);
				oops(argv[2],3);
			}

		
			//parent_stdout
			close(thepipe[0]);//close thepipe_read 
			close(thepipe[1]);//close thepipe_write
			close(pipe2[1]);//close write pipe_fd6
			if(dup2(pipe2[0],0) == -1)//dup fd5_stdin
				oops("couldn`t redirect stdin",3);
			close(pipe2[0]);//close origin read pipe_fd5
			
			if(argc==4)//three inputs
				execlp(argv[3],argv[3],NULL);
			else//four inputs 
				execlp(argv[3],argv[3],argv[4],NULL);
			oops(argv[3],4);
		}
	}
	//child1_stdin
	close(thepipe[0]);//close read pipe_fd3
	if(dup2(thepipe[1],1) == -1)//dup fd4-stdout
		oops("couldn`t redirect stdout",4);
	close(thepipe[1]);//close origin write pipe_fd4
	execlp(argv[1],argv[1],NULL);
	oops(argv[1],5);
}
