/**
 * Homework #1
 * ELEC462: System Programming
 * Instructor: Prof. Young-Kyoon Suh
 * Description: A Buggy C program to find all prime factors of a given number
 */

#include <stdio.h>
typedef enum { FALSE, TRUE } boolean;

int main(){
    int m, n, num;
    boolean isPrime = FALSE;

    /* Input a number from user */
    printf("Enter any integer number to print Prime factors: ");
    scanf("%d", &num);

    printf("All prime Factors of %d are: \n", num);

    if(num <  0){ 
        printf("Only positive numbers are supported.\n");
    }else{
	if(num == 1){
	    printf(" (none)");
	}else{
	    /* Let's find all prime factors */
	    for(m = 2; m <= num; m++){
		/* See if 'm' can be factor of 'num' */
	        if(num % m == 0){ 
			/* Check 'm' for prime */
			isPrime = TRUE;
			for(n = 2; n <= m/2; n++){ 
			        if(m % n == 0){
			           isPrime = FALSE;
				}
			}
			/* If 'm' is Prime number, then factor of num */
			if(isPrime == TRUE){
			        printf("%d ", m);
			}
    		}       
	    }
	}
    }
    printf("\n");
    return 0;
}
