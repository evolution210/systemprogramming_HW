#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

void inthandler(int s){
	printf("\nSignal CTRL+C received\n");
	exit(-1);
}

void quithandler(int s){
	printf("\nSignal CTRL+/ received\n");
	exit(-1);
}
void child_code(){
	int n, m;
	float result;
	printf("Input two numbers (x and y)\n\tI am Child %d.\n", getpid());
	while(1){
		scanf("%d %d",&n, &m);//input two integer value
		if(n == m){//identical two integer
			printf("The program received the same numbers. So the program exits.\n");
			printf("\tChild %d dead. :(\n",getpid());
			exit(-1);
		}
		else{
			result = (n+m)/2.0;
			if(result - (int)result == 0)
				printf("%d\n",(int)result);
			else	
				printf("%0.1f\n",result);
		}
	}
}

void parent_code(){
	signal(SIGINT,inthandler);
        signal(SIGQUIT,quithandler);
	int wait_rv;
	wait_rv = wait(NULL);
}

int main(int argc, char* argv[]){
	int newpid;
	void child_code(), parant_code();
	void inthandler(int);
	void quithandler(int);
	
	printf("\tI am Parent %d\n", getpid());
	if((newpid = fork()) == -1){
		perror("fork");
	}
	else if(newpid == 0){//child process
		child_code();
	}
	else{//parent process
		parent_code();
	}
	return 0;
}
